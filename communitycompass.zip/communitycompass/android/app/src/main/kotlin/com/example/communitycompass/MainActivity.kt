package com.example.communitycompass

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
