import 'package:flutter/foundation.dart';
import '../models/resource.dart';
import '../utils/resource_loader.dart';
import '../db_helper.dart';

class ResourceProvider with ChangeNotifier {
  List<Resource> _resources = [];
  bool _isLoading = false;
  String _errorMessage = '';

  List<Resource> get resources => _resources;
  bool get isLoading => _isLoading;
  bool get hasError => _errorMessage.isNotEmpty;
  String get errorMessage => _errorMessage;

  /// Load all resources from Hive, or from JSON on first launch
  Future<void> loadResources() async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      final existing = await DBHelper.getResources();

      if (existing.isEmpty) {
        final List<Resource> jsonResources = await ResourceLoader.loadResourcesFromJson();
        for (var resource in jsonResources) {
          await DBHelper.addResource(resource);
        }
        _resources = jsonResources;
      } else {
        _resources = existing;
      }

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'Failed to load resources: $e';
      notifyListeners();
    }
  }

  /// Add a new resource
  Future<void> addResource(Resource resource) async {
    _isLoading = true;
    notifyListeners();

    try {
      await DBHelper.addResource(resource);
      await loadResources(); // Refresh list
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'Failed to add resource: $e';
      notifyListeners();
    }
  }

  /// Delete resource by index
  Future<void> deleteResource(int index) async {
    _isLoading = true;
    notifyListeners();

    try {
      await DBHelper.deleteResource(index);
      await loadResources(); // Refresh list
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'Failed to delete resource: $e';
      notifyListeners();
    }
  }

  /// Search resources by keyword
  Future<void> searchResources(String query) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      _resources = await DBHelper.searchResources(query);
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'Search failed: $e';
      notifyListeners();
    }
  }

  /// Filter resources by category
  Future<List<Resource>> filterByCategory(String category) async {
    _isLoading = true;
    _errorMessage = '';
    notifyListeners();

    try {
      final filtered = await DBHelper.getResourcesByCategory(category);
      _resources = filtered;
      _isLoading = false;
      notifyListeners();
      return filtered;
    } catch (e) {
      _isLoading = false;
      _errorMessage = 'Filter failed: $e';
      notifyListeners();
      return [];
    }
  }

  /// Get resource index
  int getResourceIndex(Resource resource) {
    int index = _resources.indexOf(resource);
    if (index != -1) return index;

    for (int i = 0; i < _resources.length; i++) {
      Resource r = _resources[i];
      if (r.name == resource.name &&
          r.latitude == resource.latitude &&
          r.longitude == resource.longitude) {
        return i;
      }
    }
    return 0; // fallback
  }
}
