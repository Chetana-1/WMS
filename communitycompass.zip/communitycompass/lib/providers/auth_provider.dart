import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import 'package:flutter/material.dart';
import '../models/user.dart' as app_user;
import '../services/auth_service.dart';

class AuthProvider with ChangeNotifier {
  final AuthService _authService = AuthService();
  app_user.User? _user;
  String _errorMessage = '';
  bool _isLoading = false;

  app_user.User? get user => _user;
  bool get isAuthenticated => _user != null;
  String get errorMessage => _errorMessage;
  bool get isLoading => _isLoading;

  AuthProvider() {
    checkCurrentUser();
  }

  Future<void> checkCurrentUser() async {
    _setLoading(true);
    try {
      final currentUser = await _authService.getCurrentUser();
      if (currentUser != null) {
        _user = currentUser;
      }
    } catch (e) {
      _setError('Failed to get current user: ${e.toString()}');
    }
    _setLoading(false);
  }

  Future<bool> signIn(String email, String password) async {
    _clearError();
    _setLoading(true);

    try {
      final user = await _authService.signIn(email, password);
      _user = user;
      _setLoading(false);
      return true;
    } catch (e) {
      _handleAuthError(e);
      _setLoading(false);
      return false;
    }
  }

  Future<bool> signUp(String email, String password) async {
    _clearError();
    _setLoading(true);

    try {
      final user = await _authService.signUp(email, password);
      _user = user;
      _setLoading(false);
      return true;
    } catch (e) {
      _handleAuthError(e);
      _setLoading(false);
      return false;
    }
  }

  Future<bool> resetPassword(String email) async {
    _clearError();
    _setLoading(true);

    try {
      await _authService.resetPassword(email);
      _setLoading(false);
      return true;
    } catch (e) {
      _handleAuthError(e);
      _setLoading(false);
      return false;
    }
  }

  Future<bool> signOut() async {
    _clearError();
    _setLoading(true);

    try {
      await _authService.signOut();
      _user = null;
      _setLoading(false);
      return true;
    } catch (e) {
      _setError('Error signing out: ${e.toString()}');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> updateProfile({String? displayName, String? photoUrl}) async {
    _clearError();
    _setLoading(true);

    try {
      final updatedUser = await _authService.updateProfile(
        displayName: displayName,
        photoUrl: photoUrl,
      );
      _user = updatedUser;
      _setLoading(false);
      return true;
    } catch (e) {
      _setError('Error updating profile: ${e.toString()}');
      _setLoading(false);
      return false;
    }
  }

  Future<bool> updatePassword(String newPassword) async {
    _clearError();
    _setLoading(true);

    try {
      await _authService.updatePassword(newPassword);
      _setLoading(false);
      return true;
    } catch (e) {
      _handleAuthError(e);
      _setLoading(false);
      return false;
    }
  }

  void _handleAuthError(dynamic error) {
    String message = 'An unexpected error occurred. Please try again.';

    if (error is firebase_auth.FirebaseAuthException) {
      switch (error.code) {
        case 'user-not-found':
          message = 'No user found with this email.';
          break;
        case 'wrong-password':
          message = 'Incorrect password. Please try again.';
          break;
        case 'email-already-in-use':
          message = 'This email is already registered. Please sign in instead.';
          break;
        case 'weak-password':
          message = 'Password is too weak. Use a stronger password.';
          break;
        case 'invalid-email':
          message = 'Invalid email format.';
          break;
        case 'user-disabled':
          message = 'This account has been disabled. Please contact support.';
          break;
        case 'too-many-requests':
          message = 'Too many attempts. Please try again later.';
          break;
        case 'operation-not-allowed':
          message = 'Operation not allowed. Please contact support.';
          break;
        case 'network-request-failed':
          message = 'Network error. Please check your connection.';
          break;
        case 'requires-recent-login':
          message = 'Please re-authenticate before changing password.';
          break;
        default:
          message = 'Authentication error: ${error.message}';
      }
    }

    _setError(message);
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String message) {
    _errorMessage = message;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = '';
    notifyListeners();
  }
}
