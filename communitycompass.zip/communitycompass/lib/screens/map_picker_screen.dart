import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import '../utils/location_service.dart';

class MapPickerScreen extends StatefulWidget {
  final LatLng initialLocation;
  
  MapPickerScreen({
    this.initialLocation = const LatLng(37.7749, -122.4194), // Default to San Francisco
  });

  @override
  _MapPickerScreenState createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  late GoogleMapController _mapController;
  late LatLng _selectedLocation;
  bool _isLoading = false;
  String _address = '';

  @override
  void initState() {
    super.initState();
    _selectedLocation = widget.initialLocation;
    _checkLocationPermission();
  }

  Future<void> _checkLocationPermission() async {
    PermissionStatus status = await Permission.location.request();
    if (status.isGranted) {
      _getCurrentLocation();
    } else {
      _showPermissionDeniedDialog();
    }
  }

  Future<void> _getCurrentLocation() async {
    setState(() {
      _isLoading = true;
    });
    
    try {
      Position position = await LocationService.getCurrentPosition();
      
      setState(() {
        _selectedLocation = LatLng(position.latitude, position.longitude);
        _isLoading = false;
      });
      
      _mapController.animateCamera(CameraUpdate.newLatLng(_selectedLocation));
      _updateAddressFromCoordinates();
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      print('Error getting current location: $e');
      // Silently fail, user can select location manually
    }
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
  }

  void _onTap(LatLng location) {
    setState(() {
      _selectedLocation = location;
    });
    _updateAddressFromCoordinates();
  }
  
  Future<void> _updateAddressFromCoordinates() async {
    try {
      final address = await LocationService.getAddressFromCoordinates(
        _selectedLocation.latitude, _selectedLocation.longitude);
      
      setState(() {
        _address = address;
      });
    } catch (e) {
      setState(() {
        _address = 'Address lookup failed';
      });
      print('Error getting address: $e');
    }
  }

  void _saveLocation() {
    // Pass the selected location back to the previous screen
    Navigator.pop(context, _selectedLocation);
  }

  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Permission Denied'),
          content: Text('Please enable location services in your device settings to use this feature.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('OK'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(context);
                await openAppSettings();
              },
              child: Text('Open Settings'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pick a Location'),
        backgroundColor: Colors.teal,
      ),
      body: Stack(
        children: [
          // Map
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: _selectedLocation,
              zoom: 14.0,
            ),
            onMapCreated: _onMapCreated,
            onTap: _onTap,
            markers: {
              Marker(
                markerId: MarkerId('selected-location'),
                position: _selectedLocation,
                infoWindow: InfoWindow(title: 'Selected Location'),
              ),
            },
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: true,
            compassEnabled: true,
          ),
          
          // Loading indicator
          if (_isLoading)
            Center(
              child: CircularProgressIndicator(
                backgroundColor: Colors.white,
              ),
            ),
          
          // Bottom panel with coordinates and save button
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 8,
                    offset: Offset(0, -2),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_address.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Text(
                        _address,
                        style: TextStyle(fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  Text(
                    'Lat: ${_selectedLocation.latitude.toStringAsFixed(6)}, Lng: ${_selectedLocation.longitude.toStringAsFixed(6)}',
                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                  ),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _saveLocation,
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50),
                    ),
                    child: Text('Save Location'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
