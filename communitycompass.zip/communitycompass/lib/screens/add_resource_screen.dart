import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../models/resource.dart';
import '../providers/resource_provider.dart';
import 'map_picker_screen.dart';
import '../utils/location_service.dart';
import 'package:provider/provider.dart';

class AddResourceScreen extends StatefulWidget {
  @override
  _AddResourceScreenState createState() => _AddResourceScreenState();
}

class _AddResourceScreenState extends State<AddResourceScreen> {
  final _formKey = GlobalKey<FormState>();
  
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _categoryController = TextEditingController();
  final _locationController = TextEditingController();
  final _latitudeController = TextEditingController();
  final _longitudeController = TextEditingController();
  final _phoneController = TextEditingController();
  final _websiteController = TextEditingController();
  
  LatLng? _selectedLocation;
  bool _isLoading = false;
  
  final List<String> _categories = [
    'Food',
    'Shelter',
    'Healthcare',
    'Education',
    'Employment',
    'Clothing',
    'Transportation',
    'Other'
  ];

  @override
  void initState() {
    super.initState();
    // Try to get current location as default
    _initCurrentLocation();
  }

  Future<void> _initCurrentLocation() async {
    try {
      final position = await LocationService.getCurrentPosition();
      setState(() {
        _latitudeController.text = position.latitude.toString();
        _longitudeController.text = position.longitude.toString();
        _selectedLocation = LatLng(position.latitude, position.longitude);
      });
    } catch (e) {
      // Silently fail - user will need to enter location manually
      print('Could not get current location: $e');
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _categoryController.dispose();
    _locationController.dispose();
    _latitudeController.dispose();
    _longitudeController.dispose();
    _phoneController.dispose();
    _websiteController.dispose();
    super.dispose();
  }

  Future<void> _pickLocation() async {
    // Default location if none is selected yet
    LatLng initialLocation = _selectedLocation ?? 
      LatLng(37.7749, -122.4194); // Default to San Francisco
      
    final result = await Navigator.push<LatLng>(
      context,
      MaterialPageRoute(
        builder: (context) => MapPickerScreen(initialLocation: initialLocation),
      ),
    );
    
    if (result != null) {
      setState(() {
        _selectedLocation = result;
        _latitudeController.text = result.latitude.toString();
        _longitudeController.text = result.longitude.toString();
      });
      
      // Try to get address from coordinates
      try {
        final address = await LocationService.getAddressFromCoordinates(
          result.latitude, result.longitude);
        
        if (address.isNotEmpty) {
          setState(() {
            _locationController.text = address;
          });
        }
      } catch (e) {
        // Address lookup failed, user can enter manually
        print('Error getting address: $e');
      }
    }
  }

  void _saveResource() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        // Create a Resource object
        final newResource = Resource(
          name: _nameController.text,
          description: _descriptionController.text,
          category: _categoryController.text,
          location: _locationController.text,
          latitude: double.parse(_latitudeController.text),
          longitude: double.parse(_longitudeController.text),
          phone: _phoneController.text.isNotEmpty ? _phoneController.text : null,
          website: _websiteController.text.isNotEmpty ? _websiteController.text : null,
        );

        // Save the resource using provider
        await Provider.of<ResourceProvider>(context, listen: false)
            .addResource(newResource);

        // Show a success message and go back
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Resource added successfully!')),
        );

        Navigator.pop(context);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error adding resource: $e'),
            backgroundColor: Colors.red,
          ),
        );
        
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Resource'),
        backgroundColor: Colors.teal,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextFormField(
                      controller: _nameController,
                      decoration: InputDecoration(
                        labelText: 'Resource Name',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.business),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a resource name';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 16),
                    
                    TextFormField(
                      controller: _descriptionController,
                      decoration: InputDecoration(
                        labelText: 'Description',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.description),
                      ),
                      maxLines: 3,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a description';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 16),
                    
                    // Category dropdown
                    DropdownButtonFormField<String>(
                      decoration: InputDecoration(
                        labelText: 'Category',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.category),
                      ),
                      items: _categories.map((String category) {
                        return DropdownMenuItem<String>(
                          value: category,
                          child: Text(category),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          _categoryController.text = value!;
                        });
                      },
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please select a category';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 16),
                    
                    // Location with map picker button
                    TextFormField(
                      controller: _locationController,
                      decoration: InputDecoration(
                        labelText: 'Location Address',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.location_on),
                        suffixIcon: IconButton(
                          icon: Icon(Icons.map),
                          onPressed: _pickLocation,
                          tooltip: 'Pick location on map',
                        ),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a location';
                        }
                        return null;
                      },
                    ),
                    SizedBox(height: 16),
                    
                    // Latitude and Longitude fields in a row
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: _latitudeController,
                            decoration: InputDecoration(
                              labelText: 'Latitude',
                              border: OutlineInputBorder(),
                              prefixIcon: Icon(Icons.my_location),
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              try {
                                double lat = double.parse(value);
                                if (lat < -90 || lat > 90) {
                                  return 'Invalid';
                                }
                              } catch (e) {
                                return 'Invalid';
                              }
                              return null;
                            },
                          ),
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: TextFormField(
                            controller: _longitudeController,
                            decoration: InputDecoration(
                              labelText: 'Longitude',
                              border: OutlineInputBorder(),
                              prefixIcon: Icon(Icons.my_location),
                            ),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Required';
                              }
                              try {
                                double lng = double.parse(value);
                                if (lng < -180 || lng > 180) {
                                  return 'Invalid';
                                }
                              } catch (e) {
                                return 'Invalid';
                              }
                              return null;
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    
                    // Additional fields (optional)
                    TextFormField(
                      controller: _phoneController,
                      decoration: InputDecoration(
                        labelText: 'Phone (optional)',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.phone),
                      ),
                      keyboardType: TextInputType.phone,
                    ),
                    SizedBox(height: 16),
                    
                    TextFormField(
                      controller: _websiteController,
                      decoration: InputDecoration(
                        labelText: 'Website (optional)',
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.web),
                      ),
                      keyboardType: TextInputType.url,
                    ),
                    SizedBox(height: 24),
                    
                    ElevatedButton(
                      onPressed: _saveResource,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        padding: EdgeInsets.symmetric(vertical: 15),
                        textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      child: Text('Save Resource'),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
