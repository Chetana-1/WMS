import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'search_screen.dart';
import 'add_resource_screen.dart';
import 'category_screen.dart';
import '../utils/location_service.dart';
import '../widgets/category_card.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Position? _currentPosition;
  bool _isLoading = true;
  String _locationError = '';

  @override
  void initState() {
    super.initState();
    _initializeLocation();
  }

  Future<void> _initializeLocation() async {
    try {
      final position = await LocationService.getCurrentPosition();
      setState(() {
        _currentPosition = position;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _locationError = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Local Resource Finder'),
        backgroundColor: Colors.teal,
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SearchScreen()),
              );
            },
          ),
        ],
      ),
      body: _isLoading 
          ? Center(child: CircularProgressIndicator())
          : _buildMainContent(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddResourceScreen()),
          );
        },
        child: Icon(Icons.add),
        backgroundColor: Colors.teal,
      ),
    );
  }

  Widget _buildMainContent() {
    if (_locationError.isNotEmpty) {
      return _buildLocationErrorWidget();
    }
    
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Location info card
          if (_currentPosition != null)
            _buildLocationInfoCard(),
            
          // Categories section
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Resource Categories',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          _buildCategoriesGrid(),
          
          // Recently added section
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Recently Added Resources',
              style: Theme.of(context).textTheme.titleLarge,
            ),
          ),
          SizedBox(
            height: 150,
            child: _buildRecentResourcesList(),
          ),
        ],
      ),
    );
  }

  Widget _buildLocationErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.location_off, size: 80, color: Colors.grey),
            SizedBox(height: 20),
            Text(
              'Location services are disabled',
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 10),
            Text(
              _locationError,
              style: TextStyle(color: Colors.grey[600]),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                await Permission.location.request();
                _initializeLocation();
              },
              child: Text('Enable Location'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationInfoCard() {
    return Card(
      margin: EdgeInsets.all(16.0),
      child: Padding(
        padding: EdgeInsets.all(16.0),
        child: Row(
          children: [
            Icon(Icons.location_on, color: Colors.teal, size: 36),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Your Current Location',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Lat: ${_currentPosition!.latitude.toStringAsFixed(4)}, '
                    'Lng: ${_currentPosition!.longitude.toStringAsFixed(4)}',
                    style: TextStyle(color: Colors.grey[600]),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoriesGrid() {
    final categories = [
      {'name': 'Food', 'icon': Icons.restaurant, 'color': Colors.orange},
      {'name': 'Shelter', 'icon': Icons.home, 'color': Colors.brown},
      {'name': 'Healthcare', 'icon': Icons.local_hospital, 'color': Colors.red},
      {'name': 'Education', 'icon': Icons.school, 'color': Colors.blue},
      {'name': 'Employment', 'icon': Icons.work, 'color': Colors.green},
      {'name': 'Clothing', 'icon': Icons.shopping_bag, 'color': Colors.purple},
    ];

    return GridView.builder(
      padding: EdgeInsets.symmetric(horizontal: 16.0),
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 16.0,
        mainAxisSpacing: 16.0,
      ),
      itemCount: categories.length,
      itemBuilder: (context, index) {
        final category = categories[index];
        return CategoryCard(
          name: category['name'] as String,
          icon: category['icon'] as IconData,
          color: category['color'] as Color,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CategoryScreen(
                  category: category['name'] as String,
                  color: category['color'] as Color,
                  icon: category['icon'] as IconData,
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildRecentResourcesList() {
    return FutureBuilder(
      future: LocationService.getNearbyResources(
        _currentPosition!.latitude,
        _currentPosition!.longitude,
        5.0, // 5 km radius
      ),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        
        if (snapshot.hasError) {
          return Center(child: Text('Error loading resources'));
        }
        
        final resources = snapshot.data ?? [];
        
        if (resources.isEmpty) {
          return Center(
            child: Text('No nearby resources found'),
          );
        }
        
        return ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: resources.length,
          itemBuilder: (context, index) {
            final resource = resources[index];
            return Card(
              margin: EdgeInsets.only(left: 16, right: index == resources.length - 1 ? 16 : 0),
              child: Container(
                width: 200,
                padding: EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(resource.getCategoryIcon(), color: resource.getCategoryColor()),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            resource.name,
                            style: TextStyle(fontWeight: FontWeight.bold),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Text(
                      resource.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Spacer(),
                    Text(
                      resource.location,
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
