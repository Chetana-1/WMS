import 'package:flutter/material.dart';
import '../models/resource.dart';
import '../widgets/resource_card.dart';
import '../providers/resource_provider.dart';
import 'resource_details_screen.dart';
import 'package:provider/provider.dart';

class CategoryScreen extends StatefulWidget {
  final String category;
  final Color color;
  final IconData icon;

  CategoryScreen({
    required this.category,
    required this.color,
    required this.icon,
  });

  @override
  _CategoryScreenState createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  bool _isLoading = true;
  List<Resource> _resources = [];
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadResources();
  }

  Future<void> _loadResources() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final resources = await Provider.of<ResourceProvider>(context, listen: false)
          .filterByCategory(widget.category);

      setState(() {
        _resources = resources;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.category} Resources'),
        backgroundColor: widget.color,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _errorMessage.isNotEmpty
          ? _buildErrorWidget()
          : _buildResourcesList(),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 64, color: Colors.red[300]),
            SizedBox(height: 16),
            Text(
              'Error loading resources',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              _errorMessage,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey[700]),
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loadResources,
              child: Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResourcesList() {
    if (_resources.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(widget.icon, size: 64, color: Colors.grey[400]),
            SizedBox(height: 16),
            Text(
              'No ${widget.category} resources found',
              style: TextStyle(fontSize: 18, color: Colors.grey[700]),
            ),
            SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(Icons.arrow_back),
              label: Text('Go Back'),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: _resources.length,
      padding: EdgeInsets.all(8),
      itemBuilder: (context, index) {
        final resource = _resources[index];
        return ResourceCard(
          resource: resource,
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ResourceDetailsScreen(
                  resource: resource,
                  index: Provider.of<ResourceProvider>(context, listen: false)
                      .getResourceIndex(resource),
                ),
              ),
            ).then((_) {
              _loadResources();
            });
          },
        );
      },
    );
  }
}
