import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import '../utils/location_service.dart';

class LocationTestScreen extends StatefulWidget {
  @override
  _LocationTestScreenState createState() => _LocationTestScreenState();
}

class _LocationTestScreenState extends State<LocationTestScreen> {
  String _locationMessage = 'Fetching location...';
  bool _isPermissionGranted = false;
  bool _isLoading = true;
  String _address = '';

  @override
  void initState() {
    super.initState();
    _checkLocationPermission();
  }

  // Function to check for location permission
  Future<void> _checkLocationPermission() async {
    setState(() {
      _isLoading = true;
      _locationMessage = 'Checking location permissions...';
    });

    try {
      PermissionStatus status = await Permission.location.request();
      if (status.isGranted) {
        setState(() {
          _isPermissionGranted = true;
        });
        await _getCurrentLocation();
      } else {
        setState(() {
          _isLoading = false;
          _locationMessage = 'Location permission denied. Please enable location services to use this feature.';
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _locationMessage = 'Error checking location permission: $e';
      });
    }
  }

  // Function to get current location
  Future<void> _getCurrentLocation() async {
    if (!_isPermissionGranted) {
      await _checkLocationPermission();
      return;
    }

    setState(() {
      _locationMessage = 'Getting your current location...';
      _isLoading = true;
    });

    try {
      Position position = await LocationService.getCurrentPosition();
      
      // Try to get address from coordinates
      try {
        final address = await LocationService.getAddressFromCoordinates(
          position.latitude, position.longitude);
        
        setState(() {
          _address = address;
        });
      } catch (e) {
        print('Error getting address: $e');
        setState(() {
          _address = 'Address lookup failed';
        });
      }
      
      setState(() {
        _locationMessage = 'Current Location:\nLatitude: ${position.latitude.toStringAsFixed(6)}\nLongitude: ${position.longitude.toStringAsFixed(6)}';
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _locationMessage = 'Error getting location: $e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Location Test'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                _isPermissionGranted ? Icons.location_on : Icons.location_off,
                size: 80,
                color: _isPermissionGranted ? Colors.teal : Colors.grey,
              ),
              SizedBox(height: 30),
              
              Text(
                'Location Services',
                style: Theme.of(context).textTheme.displayLarge,
                textAlign: TextAlign.center,
              ),
              
              SizedBox(height: 20),
              
              if (_isLoading)
                CircularProgressIndicator()
              else
                Card(
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        Text(
                          _locationMessage,
                          style: TextStyle(fontSize: 16),
                          textAlign: TextAlign.center,
                        ),
                        if (_address.isNotEmpty) ...[
                          SizedBox(height: 16),
                          Text(
                            'Address:',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            _address,
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.teal[800]),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              
              SizedBox(height: 30),
              
              ElevatedButton.icon(
                onPressed: _getCurrentLocation,
                icon: Icon(Icons.refresh),
                label: Text('Refresh Location'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
              
              SizedBox(height: 16),
              
              if (!_isPermissionGranted)
                ElevatedButton.icon(
                  onPressed: () async {
                    await openAppSettings();
                  },
                  icon: Icon(Icons.settings),
                  label: Text('Open Settings'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey[700],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
