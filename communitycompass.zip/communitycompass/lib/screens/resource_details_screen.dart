import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/resource.dart';
import '../providers/resource_provider.dart';
import 'package:provider/provider.dart';

class ResourceDetailsScreen extends StatefulWidget {
  final Resource resource;
  final int index;

  ResourceDetailsScreen({
    required this.resource,
    required this.index,
  });

  @override
  _ResourceDetailsScreenState createState() => _ResourceDetailsScreenState();
}

class _ResourceDetailsScreenState extends State<ResourceDetailsScreen> {
  late GoogleMapController _mapController;
  late Set<Marker> _markers;

  @override
  void initState() {
    super.initState();
    _markers = {
      Marker(
        markerId: MarkerId('resource-location'),
        position: LatLng(widget.resource.latitude, widget.resource.longitude),
        infoWindow: InfoWindow(title: widget.resource.name),
      ),
    };
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
  }

  Future<void> _launchPhone(String phoneNumber) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not launch phone dialer')),
      );
    }
  }

  Future<void> _launchWebsite(String website) async {
    String url = website;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://$url';
    }
    
    final Uri webUri = Uri.parse(url);
    if (await canLaunchUrl(webUri)) {
      await launchUrl(webUri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not launch website')),
      );
    }
  }

  Future<void> _launchMaps() async {
    final lat = widget.resource.latitude;
    final lng = widget.resource.longitude;
    final name = Uri.encodeComponent(widget.resource.name);
    
    final Uri mapsUri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=$lat,$lng&query_place_id=$name'
    );
    
    if (await canLaunchUrl(mapsUri)) {
      await launchUrl(mapsUri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open maps')),
      );
    }
  }

  void _confirmDelete() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Delete Resource'),
          content: Text('Are you sure you want to delete this resource? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(context); // Close dialog
                
                try {
                  await Provider.of<ResourceProvider>(context, listen: false)
                      .deleteResource(widget.index);
                  
                  Navigator.pop(context); // Go back to previous screen
                  
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Resource deleted successfully')),
                  );
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error deleting resource: $e'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              },
              child: Text('Delete', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final resource = widget.resource;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(resource.name),
        backgroundColor: resource.getCategoryColor(),
        actions: [
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: _confirmDelete,
            tooltip: 'Delete Resource',
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Map view
            Container(
              height: 200,
              child: GoogleMap(
                initialCameraPosition: CameraPosition(
                  target: LatLng(resource.latitude, resource.longitude),
                  zoom: 14.0,
                ),
                onMapCreated: _onMapCreated,
                markers: _markers,
                zoomControlsEnabled: false,
                mapToolbarEnabled: false,
                myLocationButtonEnabled: false,
              ),
            ),
            
            // Category chip
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Wrap(
                children: [
                  Chip(
                    avatar: Icon(
                      resource.getCategoryIcon(),
                      color: resource.getCategoryColor(),
                      size: 18,
                    ),
                    label: Text(resource.category),
                    backgroundColor: resource.getCategoryColor().withOpacity(0.2),
                  ),
                ],
              ),
            ),
            
            // Resource details
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Description
                  Text(
                    'Description',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: 8),
                  Text(
                    resource.description,
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(height: 16),
                  
                  // Location
                  Text(
                    'Location',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.location_on, color: Colors.grey),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          resource.location,
                          style: TextStyle(fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                  
                  // Contact information (if available)
                  if (resource.phone != null && resource.phone!.isNotEmpty) ...[
                    SizedBox(height: 16),
                    Text(
                      'Contact Information',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    SizedBox(height: 8),
                    InkWell(
                      onTap: () => _launchPhone(resource.phone!),
                      child: Row(
                        children: [
                          Icon(Icons.phone, color: Colors.teal),
                          SizedBox(width: 8),
                          Text(
                            resource.phone!,
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.teal,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  
                  // Website (if available)
                  if (resource.website != null && resource.website!.isNotEmpty) ...[
                    SizedBox(height: 16),
                    InkWell(
                      onTap: () => _launchWebsite(resource.website!),
                      child: Row(
                        children: [
                          Icon(Icons.web, color: Colors.teal),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              resource.website!,
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.teal,
                                decoration: TextDecoration.underline,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  
                  SizedBox(height: 32),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _launchMaps,
        label: Text('Directions'),
        icon: Icon(Icons.directions),
        backgroundColor: resource.getCategoryColor(),
      ),
    );
  }
}
