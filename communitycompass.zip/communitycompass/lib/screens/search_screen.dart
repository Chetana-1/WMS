import 'package:flutter/material.dart';
import '../models/resource.dart';
import '../widgets/resource_card.dart';
import '../utils/location_service.dart';
import 'resource_details_screen.dart';
import '../providers/resource_provider.dart';
import 'package:provider/provider.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _searchController = TextEditingController();
  String _searchQuery = '';
  String? _selectedCategory;

  final List<String> categories = [
    'All',
    'Food',
    'Shelter',
    'Healthcare',
    'Education',
    'Employment',
    'Clothing',
    'Transportation',
  ];

  @override
  void initState() {
    super.initState();
    // Load resources when screen initializes
    Provider.of<ResourceProvider>(context, listen: false).loadResources();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _performSearch(String query) {
    setState(() {
      _searchQuery = query;
    });
    Provider.of<ResourceProvider>(context, listen: false).searchResources(query);
  }

  void _filterByCategory(String? category) {
    setState(() {
      _selectedCategory = category == 'All' ? null : category;
    });
    
    if (category == 'All') {
      Provider.of<ResourceProvider>(context, listen: false).loadResources();
    } else {
      Provider.of<ResourceProvider>(context, listen: false).filterByCategory(category!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search Resources'),
        backgroundColor: Colors.teal,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search resources...',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                contentPadding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              ),
              onChanged: _performSearch,
            ),
          ),
          
          // Category filter
          SizedBox(
            height: 50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              padding: EdgeInsets.symmetric(horizontal: 16),
              itemBuilder: (context, index) {
                final category = categories[index];
                final isSelected = _selectedCategory == category || 
                                  (category == 'All' && _selectedCategory == null);
                
                return Padding(
                  padding: EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(category),
                    selected: isSelected,
                    onSelected: (selected) {
                      if (selected) {
                        _filterByCategory(category == 'All' ? null : category);
                      }
                    },
                    backgroundColor: Colors.grey[200],
                    selectedColor: Colors.teal[100],
                    checkmarkColor: Colors.teal,
                  ),
                );
              },
            ),
          ),
          
          Divider(),
          
          // Results
          Expanded(
            child: Consumer<ResourceProvider>(
              builder: (context, provider, child) {
                if (provider.isLoading) {
                  return Center(child: CircularProgressIndicator());
                }
                
                if (provider.hasError) {
                  return Center(
                    child: Text(
                      'Error: ${provider.errorMessage}',
                      style: TextStyle(color: Colors.red),
                    ),
                  );
                }
                
                final resources = provider.resources;
                
                if (resources.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off, size: 64, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          _searchQuery.isNotEmpty 
                              ? 'No results found for "$_searchQuery"' 
                              : 'No resources found',
                          style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                        ),
                      ],
                    ),
                  );
                }
                
                return ListView.builder(
                  itemCount: resources.length,
                  padding: EdgeInsets.all(8),
                  itemBuilder: (context, index) {
                    final resource = resources[index];
                    return ResourceCard(
                      resource: resource,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ResourceDetailsScreen(
                              resource: resource,
                              index: index,
                            ),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
