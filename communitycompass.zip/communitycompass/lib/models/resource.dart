import 'package:hive/hive.dart';
import 'package:flutter/material.dart';

part 'resource.g.dart'; // This is necessary for Hive to generate code

@HiveType(typeId: 0)
class Resource extends HiveObject {
  @HiveField(0)
  final String name;

  @HiveField(1)
  final String description;

  @HiveField(2)
  final String category;

  @HiveField(3)
  final String location;

  @HiveField(4)
  final double latitude;

  @HiveField(5)
  final double longitude;

  @HiveField(6)
  final String? phone;

  @HiveField(7)
  final String? website;

  @HiveField(8)
  final List<String>? operatingHours;

  Resource({
    required this.name,
    required this.description,
    required this.category,
    required this.location,
    required this.latitude,
    required this.longitude,
    this.phone,
    this.website,
    this.operatingHours,
  });

  /// Converts a JSON map to a Resource object
  factory Resource.fromJson(Map<String, dynamic> json) {
    return Resource(
      name: json['name'],
      description: json['description'],
      category: json['category'],
      location: json['location'],
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      phone: json['phone'],
      website: json['website'],
      operatingHours: (json['operatingHours'] is String)
          ? [json['operatingHours']]
          : (json['operatingHours'] as List<dynamic>?)
          ?.map((e) => e.toString())
          .toList(),
    );
  }

  /// Converts a Resource object to a JSON map
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'description': description,
      'category': category,
      'location': location,
      'latitude': latitude,
      'longitude': longitude,
      'phone': phone,
      'website': website,
      'operatingHours': operatingHours,
    };
  }

  /// Get a displayable category icon
  IconData getCategoryIcon() {
    switch (category.toLowerCase()) {
      case 'food':
        return Icons.restaurant;
      case 'shelter':
        return Icons.home;
      case 'healthcare':
        return Icons.local_hospital;
      case 'education':
        return Icons.school;
      case 'employment':
        return Icons.work;
      case 'clothing':
        return Icons.shopping_bag;
      case 'transportation':
        return Icons.directions_bus;
      default:
        return Icons.help;
    }
  }

  /// Get category-specific color
  Color getCategoryColor() {
    switch (category.toLowerCase()) {
      case 'food':
        return Colors.orange;
      case 'shelter':
        return Colors.brown;
      case 'healthcare':
        return Colors.red;
      case 'education':
        return Colors.blue;
      case 'employment':
        return Colors.green;
      case 'clothing':
        return Colors.purple;
      case 'transportation':
        return Colors.amber;
      default:
        return Colors.teal;
    }
  }
}
