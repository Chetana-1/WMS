import 'dart:math';
import 'package:hive/hive.dart';
import 'models/resource.dart';

class DBHelper {
  static const String boxName = 'resources_box';

  /// Open the Hive box (lazy init)
  static Future<Box<Resource>> openBox() async {
    if (!Hive.isBoxOpen(boxName)) {
      return await Hive.openBox<Resource>(boxName);
    }
    return Hive.box<Resource>(boxName);
  }

  /// Add a resource to Hive
  static Future<void> addResource(Resource resource) async {
    final box = await openBox();
    await box.add(resource);
  }

  /// Get all resources
  static Future<List<Resource>> getResources() async {
    final box = await openBox();
    return box.values.toList();
  }

  /// Get resources by category (case insensitive)
  static Future<List<Resource>> getResourcesByCategory(String category) async {
    final box = await openBox();
    return box.values
        .where((resource) =>
    resource.category.toLowerCase() == category.toLowerCase())
        .toList();
  }

  /// Get nearby resources within [radiusKm]
  static Future<List<Resource>> getNearbyResources(
      double latitude, double longitude, double radiusKm) async {
    final box = await openBox();
    final allResources = box.values.toList();

    return allResources.where((resource) {
      final distance = _calculateDistance(
        latitude,
        longitude,
        resource.latitude,
        resource.longitude,
      );
      return distance <= radiusKm;
    }).toList();
  }

  /// Haversine formula for distance (km)
  static double _calculateDistance(
      double lat1, double lon1, double lat2, double lon2) {
    const double earthRadius = 6371;
    final dLat = _degreesToRadians(lat2 - lat1);
    final dLon = _degreesToRadians(lon2 - lon1);

    final a = pow(sin(dLat / 2), 2) +
        cos(_degreesToRadians(lat1)) *
            cos(_degreesToRadians(lat2)) *
            pow(sin(dLon / 2), 2);
    final c = 2 * atan2(sqrt(a), sqrt(1 - a));

    return earthRadius * c;
  }

  static double _degreesToRadians(double degrees) {
    return degrees * pi / 180;
  }

  /// Search resources by name, description, or location
  static Future<List<Resource>> searchResources(String query) async {
    final box = await openBox();
    final lowerQuery = query.toLowerCase();

    if (query.isEmpty) {
      return box.values.toList();
    }

    return box.values
        .where((resource) =>
    resource.name.toLowerCase().contains(lowerQuery) ||
        resource.description.toLowerCase().contains(lowerQuery) ||
        resource.location.toLowerCase().contains(lowerQuery))
        .toList();
  }

  /// Get resource by index (returns null if invalid)
  static Future<Resource?> getResourceById(int index) async {
    final box = await openBox();
    if (index < 0 || index >= box.length) return null;
    return box.getAt(index);
  }

  /// Update resource at a specific index
  static Future<void> updateResource(int index, Resource newResource) async {
    final box = await openBox();
    if (index >= 0 && index < box.length) {
      await box.putAt(index, newResource);
    }
  }

  /// Delete a resource by index
  static Future<void> deleteResource(int index) async {
    final box = await openBox();
    if (index >= 0 && index < box.length) {
      await box.deleteAt(index);
    }
  }
}
