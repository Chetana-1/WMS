import 'package:geolocator/geolocator.dart';
import 'package:flutter_geocoder/geocoder.dart';
import 'package:permission_handler/permission_handler.dart';

class LocationService {
  // Get current location
  static Future<Position?> getCurrentLocation() async {
    try {
      // Request location permissions
      final status = await Permission.location.request();
      
      if (status.isGranted) {
        // Check if location service is enabled
        bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
        if (!serviceEnabled) {
          throw Exception('Location services are disabled.');
        }
        
        // Get current position
        return await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 10),
        );
      } else {
        throw Exception('Location permission denied');
      }
    } catch (e) {
      print('Error getting current location: $e');
      return null;
    }
  }
  
  // Get address from coordinates
  static Future<String> getAddressFromCoordinates(double latitude, double longitude) async {
    try {
      final coordinates = Coordinates(latitude, longitude);
      final addresses = await Geocoder.local.findAddressesFromCoordinates(coordinates);
      
      if (addresses.isNotEmpty) {
        final address = addresses.first;
        
        // Create a formatted address string
        return [
          address.featureName,
          address.thoroughfare,
          address.locality,
          address.subAdminArea,
          address.postalCode,
          address.countryName,
        ]
            .where((element) => element != null && element.isNotEmpty)
            .join(', ');
      }
      
      return 'Unknown location';
    } catch (e) {
      print('Error getting address: $e');
      return 'Error retrieving address';
    }
  }
  
  // Get coordinates from address
  static Future<Coordinates?> getCoordinatesFromAddress(String address) async {
    try {
      final addresses = await Geocoder.local.findAddressesFromQuery(address);
      
      if (addresses.isNotEmpty) {
        return addresses.first.coordinates;
      }
      
      return null;
    } catch (e) {
      print('Error getting coordinates: $e');
      return null;
    }
  }
  
  // Calculate distance between two coordinates in kilometers
  static double calculateDistance(
    double startLatitude,
    double startLongitude,
    double endLatitude,
    double endLongitude,
  ) {
    return Geolocator.distanceBetween(
      startLatitude,
      startLongitude,
      endLatitude,
      endLongitude,
    ) / 1000; // Convert to kilometers
  }
  
  // Check if location permission is granted
  static Future<bool> checkLocationPermission() async {
    final status = await Permission.location.status;
    return status.isGranted;
  }
  
  // Request location permission
  static Future<bool> requestLocationPermission() async {
    final status = await Permission.location.request();
    return status.isGranted;
  }
}