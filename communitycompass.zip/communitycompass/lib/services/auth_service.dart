import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:hive/hive.dart';
import '../models/user.dart' as app_user;

class AuthService {
  final firebase_auth.FirebaseAuth _firebaseAuth = firebase_auth.FirebaseAuth.instance;
  final String _userBoxName = 'user_box';

  // Get the current logged in user (from Firebase or local storage)
  Future<app_user.User?> getCurrentUser() async {
    try {
      final firebaseUser = _firebaseAuth.currentUser;
      if (firebaseUser != null) {
        return _userFromFirebase(firebaseUser);
      }

      final box = await Hive.openBox<app_user.User>(_userBoxName);
      return box.get('current_user');
    } catch (e) {
      print('Error getting current user: $e');
      return null;
    }
  }

  // Sign in with email and password
  Future<app_user.User?> signIn(String email, String password) async {
    try {
      final credential = await _firebaseAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = credential.user;
      if (user == null) throw Exception('Failed to sign in');

      final appUser = await _userFromFirebase(user);
      await _saveUserLocally(appUser);
      return appUser;
    } catch (e) {
      print('Error signing in: $e');
      rethrow;
    }
  }

  // Sign up with email and password
  Future<app_user.User?> signUp(String email, String password) async {
    try {
      final credential = await _firebaseAuth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final user = credential.user;
      if (user == null) throw Exception('Failed to create user');

      final appUser = await _userFromFirebase(user);
      await _saveUserLocally(appUser);
      return appUser;
    } catch (e) {
      print('Error signing up: $e');
      rethrow;
    }
  }

  // Reset password
  Future<void> resetPassword(String email) async {
    try {
      await _firebaseAuth.sendPasswordResetEmail(email: email);
    } catch (e) {
      print('Error resetting password: $e');
      rethrow;
    }
  }

  // Sign out
  Future<void> signOut() async {
    try {
      await _firebaseAuth.signOut();

      final box = await Hive.openBox<app_user.User>(_userBoxName);
      await box.delete('current_user');
    } catch (e) {
      print('Error signing out: $e');
      rethrow;
    }
  }

  // Update user profile
  Future<app_user.User?> updateProfile({String? displayName, String? photoUrl}) async {
    try {
      final user = _firebaseAuth.currentUser;
      if (user == null) throw Exception('No authenticated user');

      await user.updateDisplayName(displayName);
      if (photoUrl != null) {
        await user.updatePhotoURL(photoUrl);
      }

      final updatedUser = await _userFromFirebase(user);
      await _saveUserLocally(updatedUser);
      return updatedUser;
    } catch (e) {
      print('Error updating profile: $e');
      rethrow;
    }
  }

  // 🔐 Update password
  Future<void> updatePassword(String newPassword) async {
    try {
      final user = _firebaseAuth.currentUser;
      if (user == null) {
        throw firebase_auth.FirebaseAuthException(
          code: 'user-not-found',
          message: 'No user is currently signed in.',
        );
      }
      await user.updatePassword(newPassword);
    } catch (e) {
      print('Error updating password: $e');
      rethrow;
    }
  }

  // Convert Firebase user to app user model
  Future<app_user.User> _userFromFirebase(firebase_auth.User firebaseUser) async {
    final now = DateTime.now();
    final box = await Hive.openBox<app_user.User>(_userBoxName);
    final existingUser = box.get('current_user');

    return app_user.User(
      uid: firebaseUser.uid,
      email: firebaseUser.email!,
      displayName: firebaseUser.displayName,
      photoUrl: firebaseUser.photoURL,
      createdAt: existingUser?.createdAt ?? now,
      lastLoginAt: now,
    );
  }

  // Save user to local storage
  Future<void> _saveUserLocally(app_user.User user) async {
    final box = await Hive.openBox<app_user.User>(_userBoxName);
    await box.put('current_user', user);
  }
}
