import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import '../models/resource.dart';
import '../db_helper.dart';

class ResourceLoader {
  /// Loads the JSON from assets and returns a list of Resource objects
  static Future<List<Resource>> loadResourcesFromJson({bool saveToHive = true}) async {
    try {
      // Load JSON string from asset
      final String jsonString = await rootBundle.loadString('assets/bangalore_resources.json');

      // Decode JSON into List<dynamic>
      final List<dynamic> jsonData = json.decode(jsonString);

      // Map each item to a Resource object
      List<Resource> resources = jsonData
          .map((item) => Resource.fromJson(item as Map<String, dynamic>))
          .toList();

      // Optional: Save to Hive local database
      if (saveToHive) {
        final resourceBox = await Hive.openBox<Resource>(DBHelper.boxName);
        await resourceBox.clear(); // Optional: clear old data
        await resourceBox.addAll(resources);
      }

      return resources;
    } catch (e) {
      throw Exception("Failed to load resources from JSON: $e");
    }
  }
}

