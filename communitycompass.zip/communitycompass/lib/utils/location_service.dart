import 'package:geolocator/geolocator.dart';
import 'package:flutter_geocoder/geocoder.dart';
import '../db_helper.dart';
import '../models/resource.dart';

class LocationService {
  // Get current device position with error handling
  static Future<Position> getCurrentPosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Location services are not enabled, handle accordingly
      throw 'Location services are disabled. Please enable location services in your device settings.';
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        // Permission denied, handle accordingly
        throw 'Location permissions are denied. Please allow location access to use this feature.';
      }
    }
    
    if (permission == LocationPermission.deniedForever) {
      // Permissions are denied forever, handle accordingly.
      throw 'Location permissions are permanently denied. Please allow location access in app settings.';
    } 

    // When we reach here, permissions are granted and we can
    // continue accessing the position of the device.
    try {
      return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 10),
      );
    } catch (e) {
      throw 'Error getting location: $e';
    }
  }
  
  // Get address from coordinates
  static Future<String> getAddressFromCoordinates(double latitude, double longitude) async {
    try {
      final coordinates = Coordinates(latitude, longitude);
      final addresses = await Geocoder.local.findAddressesFromCoordinates(coordinates);
      
      if (addresses.isEmpty) {
        return 'Address not found';
      }
      
      final first = addresses.first;
      // Format the address
      final formattedAddress = [
        first.thoroughfare,
        first.locality,
        first.adminArea,
        first.postalCode,
        first.countryName,
      ].where((element) => element != null && element.isNotEmpty).join(', ');
      
      return formattedAddress.isNotEmpty ? formattedAddress : 'Address not found';
    } catch (e) {
      print('Error getting address: $e');
      return 'Address lookup failed';
    }
  }
  
  // Get nearby resources
  static Future<List<Resource>> getNearbyResources(double latitude, double longitude, double radiusKm) async {
    try {
      return await DBHelper.getNearbyResources(latitude, longitude, radiusKm);
    } catch (e) {
      print('Error getting nearby resources: $e');
      return [];
    }
  }
  
  // Calculate distance between user and a resource in kilometers
  static double calculateDistance(double userLat, double userLng, double resourceLat, double resourceLng) {
    return Geolocator.distanceBetween(
      userLat, userLng, resourceLat, resourceLng
    ) / 1000; // Convert meters to kilometers
  }
}